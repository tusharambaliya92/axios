import React,{useState} from 'react'
import axios from 'axios'

function FetchNews ()  {
    const[news,setNews] = useState([])
   
      const fetchNews =() =>{
      axios.get(" https://newsapi.org/v2/top-headlines?country=us&apiKey=9a8844ce9c15471eb89037194c3f51bb")
      .then((response)=>{
       console.log(response);
       setNews(response.data.articles)
      })
    }
  return (
    <>
  <div ClassNameName ="container my-4">
    <div ClassNameName="row">
        <div ClassNameName='col-4'>
        <button ClassNameName='btn btn-primary' onClick={fetchNews}>FetchNews</button>
        </div>
    </div>
  </div>

  <div ClassNameName ="container my-4">
    <div ClassNameName="row">
          {
            news.map((value)=>{
                return(
                    <div ClassName="card" style={{width: "18rem"}}>
  <img src={value.urlToImage} ClassName="card-img-top" alt="..."/>
  <div ClassName="card-body">
    <h5 ClassName="card-title">{value.title}</h5>
    <p ClassName="card-text">{value.description}</p>
    <a href="#" ClassName="btn btn-primary">Main</a>
  </div>
</div>
                )
                    
                
                
            })
          }
            </div>
            </div>
    </>
  )
}

export default FetchNews
