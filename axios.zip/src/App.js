
import './App.css';
import FetchNews from './compnents/FetchNews';

function App() {
  return (
    <div className="App">
      <FetchNews/>
    </div>
  );
}

export default App;
